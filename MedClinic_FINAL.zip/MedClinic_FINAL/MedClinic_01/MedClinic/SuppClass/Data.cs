﻿using MedClinic.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedClinic.SuppClass
{
    class Data
    {
        public static Entities context = new Entities();
    }
}
