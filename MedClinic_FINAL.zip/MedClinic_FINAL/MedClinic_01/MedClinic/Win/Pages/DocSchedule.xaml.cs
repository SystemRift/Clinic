﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MedClinic.Win.Pages
{
    /// <summary>
    /// Логика взаимодействия для DocSchedule.xaml
    /// </summary>
    public partial class DocSchedule : Page
    {
        public DocSchedule()
        {
            InitializeComponent();

            TimeTable Doc1 = new TimeTable();
            DTSchedule.Items.Add(Doc1);
            Doc1.Time = "09:00";
            Doc1.Tuesday = "Doc 1";
            Doc1.Friday = "Doc 1";
            Doc1.Monday = "Doc 1";

            TimeTable Doc2 = new TimeTable();
            DTSchedule.Items.Add(Doc2);
            Doc2.Time = "12:00";
            Doc2.Wednesday = "Doc 2";
            Doc2.Saturday = "Doc 2";
            Doc2.Thursday = "Doc 2";

            TimeTable Doc3 = new TimeTable();
            DTSchedule.Items.Add(Doc3);
            Doc3.Time = "15:00";
            Doc3.Monday = "Doc 3";
            Doc3.Friday = "Doc 3";
            Doc3.Thursday = "Doc 3";
        }

        public class TimeTable 
        {
            public string Time { get; set; }
            public string Monday { get; set; }
            public string Tuesday { get; set; }
            public string Wednesday { get; set; }
            public string Thursday { get; set; }
            public string Friday { get; set; }
            public string Saturday { get; set; }
        }

        private void AppointBtn_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
