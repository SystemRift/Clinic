﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static MedClinic.SuppClass.Data;

namespace MedClinic.Win.Pages
{
    /// <summary>
    /// Логика взаимодействия для PatientList.xaml
    /// </summary>
    public partial class PatientList : Page
    {
        public PatientList()
        {
            InitializeComponent();
            LvPatientList.ItemsSource = context.PatientView.ToList();
            Filter();
        }
        private void Filter()
        {
            var LvPList = context.PatientView.Where(i => i.FIO.Contains(F_Name.Text))
                            .Where(i => i.FIO.Contains(F_Name.Text))
                            .Where(i => i.FIO.Contains(F_Name.Text))
                            .Where(i => i.Email.Contains(F_Email.Text))
                            .Where(i => i.TelNum.Contains(F_TelNum.Text))
                            .ToList();

            LvPatientList.ItemsSource = LvPList;
        }

        private void Pages(int a)
        {

        }

        private void Txt_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Filter();
        }

        private void Cmb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            // Filter();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {

            // Filter();
        }

        private void BtnNext_Click(object sender, RoutedEventArgs e)
        {

            // Filter();
        }

        private void Btn1_Click(object sender, RoutedEventArgs e)
        {
            //Filter();
        }

        private void Btn2_Click(object sender, RoutedEventArgs e)
        {
            // Filter();
        }

        private void Btn3_Click(object sender, RoutedEventArgs e)
        {
            // Filter();
        }


        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            F_Email.Clear();
            F_Name.Clear();
            F_TelNum.Clear();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void F_Name_TextChanged(object sender, TextChangedEventArgs e)
        {
            Filter();
        }

        private void F_TelNum_TextChanged(object sender, TextChangedEventArgs e)
        {
            Filter();
        }

        private void F_Email_TextChanged(object sender, TextChangedEventArgs e)
        {
            Filter();
        }

        private void LvPatientList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
